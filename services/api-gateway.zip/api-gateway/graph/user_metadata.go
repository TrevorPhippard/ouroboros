package graph

import (
	"context"
	"fmt"
	"log"
	"strings"
	"sync"
	"time"

	"api-gateway/graph/model"

	authpb "ouroboros/proto/generated/auth"
	connpb "ouroboros/proto/generated/connection"
	profilepb "ouroboros/proto/generated/profile"
)

// maxConcurrentUserRPCs bounds the fan-out of per-user connection lookups that
// a single user batch performs.
const maxConcurrentUserRPCs = 16

// fetchUsers is the batch function behind Loaders.Users. It assembles complete
// User objects from three services using one auth call, one profile call and
// (concurrently) the per-user connection counts. Users unknown to the auth
// service are omitted, which the loader surfaces as nil.
func (r *Resolver) fetchUsers(ctx context.Context, ids []string) (map[string]*model.User, error) {
	ids = uniqueIDs(ids)
	if len(ids) == 0 {
		return map[string]*model.User{}, nil
	}

	authRes, err := r.AuthClient.GetUsersByIds(ctx, &authpb.GetUsersByIdsRequest{Ids: ids})
	if err != nil {
		return nil, err
	}
	if authRes == nil {
		return nil, fmt.Errorf("auth service returned an empty user response")
	}

	users := make(map[string]*model.User, len(authRes.Users))
	for _, user := range authRes.Users {
		if user == nil || strings.TrimSpace(user.Id) == "" {
			continue
		}
		users[user.Id] = &model.User{
			ID:       user.Id,
			Email:    user.Email,
			Username: user.Username,
		}
	}
	if len(users) == 0 {
		return users, nil
	}

	r.applyProfiles(ctx, users, ids)
	r.applyConnectionData(ctx, users)
	return users, nil
}

// applyProfiles overlays profile fields. A profile outage degrades the result
// (no display name / avatar / bio) instead of failing the whole lookup.
func (r *Resolver) applyProfiles(ctx context.Context, users map[string]*model.User, ids []string) {
	profileRes, err := r.ProfileClient.GetProfilesByUserIds(ctx, &profilepb.GetProfilesByUserIdsRequest{UserIds: ids})
	if err != nil {
		log.Printf("api-gateway: failed to batch load profiles for %d users: %v", len(ids), err)
		return
	}
	if profileRes == nil {
		log.Printf("api-gateway: profile service returned an empty response for %d users", len(ids))
		return
	}

	for _, profile := range profileRes.Profiles {
		if profile == nil || strings.TrimSpace(profile.UserId) == "" {
			continue
		}
		// User.email and User.username are non-null in the schema, so never
		// synthesize a partial User for a profile without an auth account.
		user := users[profile.UserId]
		if user == nil {
			continue
		}
		if profile.DisplayName != "" {
			user.DisplayName = stringPtr(profile.DisplayName)
		}
		if profile.AvatarUrl != "" {
			user.AvatarURL = stringPtr(profile.AvatarUrl)
		}
		if profile.Bio != "" {
			user.Bio = stringPtr(profile.Bio)
		}
	}
}

// applyConnectionData fills follower/following counts and isFollowing. The
// connection service has no batch RPC, so lookups run concurrently (bounded).
// Failures leave the zero value, matching the previous behaviour.
func (r *Resolver) applyConnectionData(ctx context.Context, users map[string]*model.User) {
	viewerID := currentUserIDFromContext(ctx)

	var (
		wg  sync.WaitGroup
		sem = make(chan struct{}, maxConcurrentUserRPCs)
	)
	spawn := func(fn func()) {
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			defer func() { <-sem }()
			fn()
		}()
	}

	// Every task writes a distinct field of a distinct user, so no locking is
	// needed; the map itself is only read here.
	for _, user := range users {
		user := user
		spawn(func() {
			res, err := r.ConnectionClient.GetFollowersCount(ctx, &connpb.UserRequest{UserId: user.ID})
			if err != nil {
				log.Printf("api-gateway: followers count for %s: %v", user.ID, err)
				return
			}
			if res != nil {
				user.FollowersCount = res.Count
			}
		})
		spawn(func() {
			res, err := r.ConnectionClient.GetFollowingCount(ctx, &connpb.UserRequest{UserId: user.ID})
			if err != nil {
				log.Printf("api-gateway: following count for %s: %v", user.ID, err)
				return
			}
			if res != nil {
				user.FollowingCount = res.Count
			}
		})
		if viewerID != "" && viewerID != user.ID {
			spawn(func() {
				res, err := r.ConnectionClient.IsFollowing(ctx, &connpb.IsFollowingRequest{
					FollowerId: viewerID,
					FolloweeId: user.ID,
				})
				if err != nil {
					log.Printf("api-gateway: isFollowing %s->%s: %v", viewerID, user.ID, err)
					return
				}
				if res != nil {
					user.IsFollowing = res.IsFollowing
				}
			})
		}
	}
	wg.Wait()
}

func uniqueIDs(values []string) []string {
	seen := make(map[string]struct{}, len(values))
	result := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		if _, ok := seen[value]; ok {
			continue
		}
		seen[value] = struct{}{}
		result = append(result, value)
	}
	return result
}

func stringPtr(value string) *string {
	v := value
	return &v
}

type (
	userIDContextKey     struct{}
	authExpiryContextKey struct{}
)

// WithUserID adds an identity that has already been authenticated by trusted
// middleware. Callers must not populate it directly from an arbitrary request
// header or query parameter.
func WithUserID(ctx context.Context, userID string) context.Context {
	return context.WithValue(ctx, userIDContextKey{}, strings.TrimSpace(userID))
}

// WithAuthExpiry records when the authenticated identity's token expires so
// long-lived operations (subscriptions) can end when it does.
func WithAuthExpiry(ctx context.Context, expiresAt time.Time) context.Context {
	return context.WithValue(ctx, authExpiryContextKey{}, expiresAt)
}

func authExpiryFromContext(ctx context.Context) (time.Time, bool) {
	t, ok := ctx.Value(authExpiryContextKey{}).(time.Time)
	return t, ok && !t.IsZero()
}

func mapProfile(p *profilepb.Profile) *model.Profile {
	if p == nil {
		return nil
	}

	experiences := make([]*model.Experience, 0, len(p.Experiences))

	for _, e := range p.Experiences {
		if e == nil {
			continue
		}

		experiences = append(experiences, &model.Experience{
			ID:          e.Id,
			Title:       e.Title,
			Company:     e.Company,
			StartDate:   e.StartDate,
			EndDate:     optionalString(e.EndDate),
			Description: e.Description,
		})
	}

	return &model.Profile{
		ID:          p.Id,
		UserID:      p.UserId,
		Headline:    optionalString(p.Headline),
		About:       optionalString(p.About),
		DisplayName: optionalString(p.DisplayName),
		AvatarURL:   optionalString(p.AvatarUrl),
		Bio:         optionalString(p.Bio),
		Experiences: experiences,
	}
}
