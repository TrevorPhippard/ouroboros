package graph

import (
	"context"
	"errors"

	"api-gateway/graph/model"
)

// ErrUnavailable is returned when a field depends on a downstream capability
// that this deployment has not wired up (see PostCatalog and Recommender).
var ErrUnavailable = errors.New("not available: the downstream service does not expose this capability")

// PostCatalog is the read side of the Post service that goes beyond fetching
// posts by ID: listing posts, listing a user's posts and listing comments.
//
// These are expressed in the gateway's own types so that the resolvers, the
// data loaders, authorization and limit handling are fully implemented and
// tested independently of the protobuf definitions. The gRPC-backed
// implementation lives in cmd/catalog_grpc.go (build tag "postext") and needs
// the RPCs described in docs/proto-extensions.md.
//
// Implementations must:
//   - return at most `limit` entries per key, newest first;
//   - omit keys that have no entries (or return empty slices);
//   - be safe for concurrent use.
type PostCatalog interface {
	// ListPosts returns the most recent posts across all authors.
	ListPosts(ctx context.Context, limit int32) ([]*model.Post, error)
	// PostsByAuthors returns each author's most recent posts, keyed by author ID.
	PostsByAuthors(ctx context.Context, authorIDs []string, limit int32) (map[string][]*model.Post, error)
	// CommentsByPosts returns each post's most recent comments, keyed by post ID.
	CommentsByPosts(ctx context.Context, postIDs []string, limit int32) (map[string][]*model.Comment, error)
}

// Recommender suggests accounts for a user to follow.
type Recommender interface {
	// RecommendedUserIDs returns up to limit user IDs, best match first. It
	// must not include userID itself or accounts userID already follows.
	RecommendedUserIDs(ctx context.Context, userID string, limit int32) ([]string, error)
}
