package graph

import (
	"context"
	"log"
	"sort"
	"time"

	"api-gateway/graph/model"

	notificationpb "ouroboros/proto/generated/notification"
)

const (
	defaultNotificationPollInterval = 3 * time.Second
	// subscriptionPageSize is how many of the user's newest notifications each
	// poll inspects. It only needs to exceed the number that can arrive within
	// one poll interval.
	subscriptionPageSize = 50
	// subscriptionBuffer lets a poll deliver a burst without blocking on a slow
	// client; beyond it, delivery applies backpressure to the poller.
	subscriptionBuffer = 16
)

// streamNotifications polls the Notification service and emits each
// notification the first time it is seen, oldest first, until ctx is done or the
// bearer token the subscription was authorized with expires. The caller owns
// closing events.
func (r *Resolver) streamNotifications(
	ctx context.Context,
	userID string,
	interval time.Duration,
	seen map[string]struct{},
	events chan<- *model.Notification,
) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}

		if expiry, ok := authExpiryFromContext(ctx); ok && !time.Now().Before(expiry) {
			return // the token this subscription was authorized with has expired
		}

		latest, err := r.fetchNotifications(ctx, userID, subscriptionPageSize)
		if err != nil {
			// Transient downstream failures must not kill the subscription.
			log.Printf("api-gateway: notification poll failed user_id=%s: %v", userID, err)
			continue
		}

		fresh := make([]*model.Notification, 0, len(latest))
		for _, n := range latest {
			if _, already := seen[n.ID]; !already {
				fresh = append(fresh, n)
			}
		}
		// Only IDs from the latest window can recur, so replacing the set keeps
		// memory bounded for arbitrarily long-lived subscriptions.
		seen = idSet(latest)

		// Deliver oldest first. CreatedAt is RFC 3339 so it sorts lexically.
		sort.SliceStable(fresh, func(i, j int) bool { return fresh[i].CreatedAt < fresh[j].CreatedAt })
		for _, n := range fresh {
			select {
			case events <- n:
			case <-ctx.Done():
				return
			}
		}
	}
}

// fetchNotifications loads and maps a user's newest notifications.
func (r *Resolver) fetchNotifications(ctx context.Context, userID string, limit int32) ([]*model.Notification, error) {
	res, err := r.NotificationClient.GetNotifications(ctx, &notificationpb.GetNotificationsRequest{
		UserId: userID,
		Limit:  limit,
	})
	if err != nil {
		return nil, err
	}
	if res == nil {
		return []*model.Notification{}, nil
	}

	notifications := make([]*model.Notification, 0, len(res.Notifications))
	for _, n := range res.Notifications {
		if n == nil {
			continue
		}
		notifications = append(notifications, &model.Notification{
			ID:        n.Id,
			UserID:    n.UserId,
			Type:      n.Type,
			ActorID:   n.ActorId,
			EntityID:  optionalString(n.EntityId),
			CreatedAt: n.CreatedAt,
			Read:      n.Read,
		})
	}
	return notifications, nil
}

func idSet(notifications []*model.Notification) map[string]struct{} {
	set := make(map[string]struct{}, len(notifications))
	for _, n := range notifications {
		set[n.ID] = struct{}{}
	}
	return set
}
