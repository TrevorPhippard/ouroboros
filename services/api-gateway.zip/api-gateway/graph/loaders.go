package graph

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"strings"

	"api-gateway/graph/dataloader"
	"api-gateway/graph/model"

	"github.com/99designs/gqlgen/graphql"
	"github.com/vektah/gqlparser/v2/ast"

	postpb "ouroboros/proto/generated/post"
)

// Loaders are the per-operation data loaders. A fresh set is created for every
// GraphQL operation (see LoaderExtension) so cached data can never cross
// requests or users, and every key requested while one level of the query is
// being resolved is fetched with a single downstream call.
//
//	Without loaders:  posts(10) { author }   -> 1 + 10 author lookups (each with 3+ RPCs)
//	With loaders:     posts(10) { author }   -> 1 + 1 batched lookup
type Loaders struct {
	// Users resolves a full User (auth + profile + follow counts + isFollowing
	// relative to the viewer) by ID. Missing users resolve to nil.
	Users *dataloader.Loader[string, *model.User]
	// Posts resolves a post by ID. Missing posts resolve to nil.
	Posts *dataloader.Loader[string, *model.Post]
	// PostsByAuthor resolves an author's latest posts.
	PostsByAuthor *dataloader.Loader[listKey, []*model.Post]
	// Comments resolves a post's latest comments.
	Comments *dataloader.Loader[listKey, []*model.Comment]
}

// listKey identifies a "first N items of parent X" lookup. The limit is part of
// the key because the same parent can be requested with different limits via
// GraphQL aliases.
type listKey struct {
	ID    string
	Limit int32
}

type loadersContextKey struct{}

// NewLoaders builds a fresh set of loaders bound to ctx. ctx must carry the
// caller's auth metadata and user ID because batch functions run with it.
func NewLoaders(ctx context.Context, r *Resolver, cfg dataloader.Config) *Loaders {
	return &Loaders{
		Users: dataloader.New(ctx, cfg, r.fetchUsers),
		Posts: dataloader.New(ctx, cfg, r.fetchPosts),
		PostsByAuthor: dataloader.New(ctx, cfg, func(ctx context.Context, keys []listKey) (map[listKey][]*model.Post, error) {
			return r.fetchPostsByAuthor(ctx, keys)
		}),
		Comments: dataloader.New(ctx, cfg, func(ctx context.Context, keys []listKey) (map[listKey][]*model.Comment, error) {
			return r.fetchComments(ctx, keys)
		}),
	}
}

// WithLoaders stores loaders in ctx.
func WithLoaders(ctx context.Context, l *Loaders) context.Context {
	return context.WithValue(ctx, loadersContextKey{}, l)
}

// LoadersFrom returns the operation's loaders, or nil when none are installed.
func LoadersFrom(ctx context.Context) *Loaders {
	l, _ := ctx.Value(loadersContextKey{}).(*Loaders)
	return l
}

// loaders returns the operation's loaders. When none are installed (for
// example a resolver invoked directly from a unit test) it falls back to
// uncached single-use loaders: slower, but still correct.
func (r *Resolver) loaders(ctx context.Context) *Loaders {
	if l := LoadersFrom(ctx); l != nil {
		return l
	}
	return NewLoaders(ctx, r, dataloader.Config{DisableCache: true})
}

// LoaderExtension is a gqlgen extension that installs fresh Loaders for every
// operation, over HTTP and WebSocket alike. Add it with srv.Use(...).
func LoaderExtension(r *Resolver) graphql.HandlerExtension { return loaderExtension{r: r} }

type loaderExtension struct{ r *Resolver }

var _ graphql.OperationInterceptor = loaderExtension{}

func (loaderExtension) ExtensionName() string                   { return "DataLoaders" }
func (loaderExtension) Validate(graphql.ExecutableSchema) error { return nil }

func (e loaderExtension) InterceptOperation(ctx context.Context, next graphql.OperationHandler) graphql.ResponseHandler {
	cfg := dataloader.Config{}
	// A subscription lives for as long as the socket does and re-resolves
	// nested fields for every event, so caching would serve stale users.
	if oc := graphql.GetOperationContext(ctx); oc != nil && oc.Operation != nil && oc.Operation.Operation == ast.Subscription {
		cfg.DisableCache = true
	}
	return next(WithLoaders(ctx, NewLoaders(ctx, e.r, cfg)))
}

// LoaderMiddleware is an http.Handler middleware alternative to LoaderExtension
// for servers that are not built on gqlgen's handler package.
func LoaderMiddleware(r *Resolver, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		ctx := req.Context()
		next.ServeHTTP(w, req.WithContext(WithLoaders(ctx, NewLoaders(ctx, r, dataloader.Config{}))))
	})
}

// ---------------------------------------------------------------------------
// Batch functions
// ---------------------------------------------------------------------------

// fetchPosts resolves posts by ID with one GetPostsByIds call.
func (r *Resolver) fetchPosts(ctx context.Context, ids []string) (map[string]*model.Post, error) {
	ids = uniqueIDs(ids)
	posts := make(map[string]*model.Post, len(ids))
	if len(ids) == 0 {
		return posts, nil
	}
	res, err := r.PostClient.GetPostsByIds(ctx, &postpb.GetPostsByIdsRequest{Ids: ids})
	if err != nil {
		return nil, fmt.Errorf("failed to fetch posts: %w", err)
	}
	if res == nil {
		return posts, nil
	}
	for _, p := range res.Posts {
		if p == nil {
			continue
		}
		posts[p.Id] = mapPost(p)
	}
	return posts, nil
}

// fetchPostsByAuthor groups keys by limit and issues one catalog call per
// distinct limit (normally exactly one).
func (r *Resolver) fetchPostsByAuthor(ctx context.Context, keys []listKey) (map[listKey][]*model.Post, error) {
	out := make(map[listKey][]*model.Post, len(keys))
	if r.Catalog == nil {
		// Nested lists degrade to empty rather than failing the whole query;
		// Query.posts, which has nothing else to return, reports ErrUnavailable.
		for _, k := range keys {
			out[k] = []*model.Post{}
		}
		return out, nil
	}
	for limit, ids := range groupByLimit(keys) {
		byAuthor, err := r.Catalog.PostsByAuthors(ctx, ids, limit)
		if err != nil {
			return nil, fmt.Errorf("failed to fetch posts by author: %w", err)
		}
		for _, id := range ids {
			out[listKey{ID: id, Limit: limit}] = capPosts(byAuthor[id], limit)
		}
	}
	return out, nil
}

func (r *Resolver) fetchComments(ctx context.Context, keys []listKey) (map[listKey][]*model.Comment, error) {
	out := make(map[listKey][]*model.Comment, len(keys))
	if r.Catalog == nil {
		for _, k := range keys {
			out[k] = []*model.Comment{}
		}
		return out, nil
	}
	for limit, ids := range groupByLimit(keys) {
		byPost, err := r.Catalog.CommentsByPosts(ctx, ids, limit)
		if err != nil {
			return nil, fmt.Errorf("failed to fetch comments: %w", err)
		}
		for _, id := range ids {
			out[listKey{ID: id, Limit: limit}] = capComments(byPost[id], limit)
		}
	}
	return out, nil
}

// groupByLimit returns the distinct IDs for each limit, in a stable order.
func groupByLimit(keys []listKey) map[int32][]string {
	grouped := make(map[int32][]string)
	for _, k := range keys {
		grouped[k.Limit] = append(grouped[k.Limit], k.ID)
	}
	for limit := range grouped {
		sort.Strings(grouped[limit])
	}
	return grouped
}

// capPosts enforces the limit even if a catalog returns more than asked for,
// and never returns nil (GraphQL non-null lists must serialize as []).
func capPosts(posts []*model.Post, limit int32) []*model.Post {
	out := make([]*model.Post, 0, len(posts))
	for _, p := range posts {
		if p == nil {
			continue
		}
		out = append(out, p)
		if int32(len(out)) >= limit {
			break
		}
	}
	return out
}

func capComments(comments []*model.Comment, limit int32) []*model.Comment {
	out := make([]*model.Comment, 0, len(comments))
	for _, c := range comments {
		if c == nil {
			continue
		}
		out = append(out, c)
		if int32(len(out)) >= limit {
			break
		}
	}
	return out
}

// loadUsersByID resolves users through the operation's loaders. Users that do
// not exist map to nil. IDs are trimmed and de-duplicated.
func (r *Resolver) loadUsersByID(ctx context.Context, ids []string) (map[string]*model.User, error) {
	ids = uniqueIDs(ids)
	if len(ids) == 0 {
		return map[string]*model.User{}, nil
	}
	return r.loaders(ctx).Users.LoadMany(ctx, ids)
}

// loadUser resolves one user, or nil if the user does not exist.
func (r *Resolver) loadUser(ctx context.Context, id string) (*model.User, error) {
	id = strings.TrimSpace(id)
	if id == "" {
		return nil, nil
	}
	return r.loaders(ctx).Users.Load(ctx, id)
}
