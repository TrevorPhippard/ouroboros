package graph

import (
	"time"

	authpb "ouroboros/proto/generated/auth"
	connpb "ouroboros/proto/generated/connection"
	feedpb "ouroboros/proto/generated/feed"
	notificationpb "ouroboros/proto/generated/notification"
	postpb "ouroboros/proto/generated/post"
	profilepb "ouroboros/proto/generated/profile"
)

// Resolver holds all dependencies required by GraphQL resolvers.
// It acts as the dependency injection container for the GraphQL API.
type Resolver struct {
	AuthClient         authpb.AuthServiceClient
	ConnectionClient   connpb.ConnectionServiceClient
	FeedClient         feedpb.FeedServiceClient
	NotificationClient notificationpb.NotificationServiceClient
	PostClient         postpb.PostServiceClient
	ProfileClient      profilepb.ProfileServiceClient

	// Catalog backs Query.posts, User.posts and Post.comments. Optional: when
	// nil, Query.posts reports ErrUnavailable and the nested lists are empty.
	Catalog PostCatalog
	// Recommender backs Query.recommendations. Optional: when nil the query
	// reports ErrUnavailable.
	Recommender Recommender

	// NotificationPollInterval is how often a notificationReceived subscription
	// asks the Notification service for new items. Defaults to 3s.
	NotificationPollInterval time.Duration
}

// The accessor methods (Query(), Mutation(), User(), Post(), ...) and the
// per-type resolver structs live at the bottom of the matching *.resolvers.go
// files; gqlgen maintains them. Keep every helper OUT of *.resolvers.go files:
// gqlgen comments out anything in them that is not a resolver method.
