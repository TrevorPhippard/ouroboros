package graph

import (
	"context"
	"fmt"
	"strings"
)

const (
	// maxListLimit caps every client-supplied `limit` so one query cannot ask
	// a downstream service for an unbounded page.
	maxListLimit = 100
	// maxIDsPerQuery caps ID-list arguments (users, profiles, postsByIds).
	maxIDsPerQuery = 200
)

func optionalString(s string) *string {
	if s == "" {
		return nil
	}

	value := s
	return &value
}

// clampLimit applies a default to a nil limit and rejects out-of-range values.
func clampLimit(limit *int32, def int32) (int32, error) {
	if limit == nil {
		return def, nil
	}
	if *limit < 1 || *limit > maxListLimit {
		return 0, fmt.Errorf("limit must be between 1 and %d", maxListLimit)
	}
	return *limit, nil
}

// checkIDCount rejects oversized ID-list arguments.
func checkIDCount(name string, ids []string) error {
	if len(ids) > maxIDsPerQuery {
		return fmt.Errorf("%s accepts at most %d ids", name, maxIDsPerQuery)
	}
	return nil
}

// currentUserIDFromContext returns only an identity established by trusted
// authentication middleware. Never synthesize a fallback identity: doing so
// lets unauthenticated requests act as a real user.
func currentUserIDFromContext(ctx context.Context) string {
	if ctx == nil {
		return ""
	}
	if userID, ok := ctx.Value(userIDContextKey{}).(string); ok {
		return strings.TrimSpace(userID)
	}
	return ""
}

func requireCurrentUserID(ctx context.Context) (string, error) {
	userID := currentUserIDFromContext(ctx)
	if userID == "" {
		return "", fmt.Errorf("unauthorized")
	}
	return userID, nil
}

// defaultRecommendationCount is how many suggestions `recommendations` returns.
const defaultRecommendationCount = 10
