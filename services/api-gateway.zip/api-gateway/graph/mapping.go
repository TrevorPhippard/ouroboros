package graph

import (
	"api-gateway/graph/model"

	postpb "ouroboros/proto/generated/post"
)

// Helpers live here (not in *.resolvers.go): gqlgen rewrites resolver files and
// comments out anything in them that is not a resolver method.

func mapPost(p *postpb.Post) *model.Post {
	if p == nil {
		return nil
	}

	return &model.Post{
		ID:        p.Id,
		Content:   p.Content,
		CreatedAt: p.CreatedAt,
		// The previous code stored the post's own ID here, so Post.UserId
		// (and therefore Post.author) pointed at a non-existent user.
		UserID: p.AuthorId,
	}
}

func mapComment(c *postpb.Comment) *model.Comment {
	if c == nil {
		return nil
	}
	return &model.Comment{
		ID:        c.Id,
		PostID:    c.PostId,
		UserID:    c.AuthorId,
		Content:   c.Content,
		CreatedAt: c.CreatedAt,
	}
}
