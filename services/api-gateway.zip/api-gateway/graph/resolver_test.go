package graph

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"api-gateway/graph/dataloader"
	"api-gateway/graph/model"

	"google.golang.org/grpc"

	authpb "ouroboros/proto/generated/auth"
	connpb "ouroboros/proto/generated/connection"
	feedpb "ouroboros/proto/generated/feed"
	notificationpb "ouroboros/proto/generated/notification"
	postpb "ouroboros/proto/generated/post"
	profilepb "ouroboros/proto/generated/profile"
)

// The fakes embed the generated client interfaces so they keep compiling when
// the services gain RPCs; only the methods a test needs are implemented.

type fakeAuth struct {
	authpb.AuthServiceClient
	calls atomic.Int32
}

func (f *fakeAuth) GetUsersByIds(_ context.Context, in *authpb.GetUsersByIdsRequest, _ ...grpc.CallOption) (*authpb.GetUsersByIdsResponse, error) {
	f.calls.Add(1)
	res := &authpb.GetUsersByIdsResponse{}
	for _, id := range in.Ids {
		if id != "ghost" {
			res.Users = append(res.Users, &authpb.User{Id: id, Email: id + "@x.io", Username: id})
		}
	}
	return res, nil
}

type fakeProfile struct {
	profilepb.ProfileServiceClient
	calls atomic.Int32
}

func (f *fakeProfile) GetProfilesByUserIds(_ context.Context, in *profilepb.GetProfilesByUserIdsRequest, _ ...grpc.CallOption) (*profilepb.GetProfilesByUserIdsResponse, error) {
	f.calls.Add(1)
	res := &profilepb.GetProfilesByUserIdsResponse{}
	for _, id := range in.UserIds {
		res.Profiles = append(res.Profiles, &profilepb.Profile{Id: "p-" + id, UserId: id, DisplayName: "Name " + id})
	}
	return res, nil
}

type fakeConn struct {
	connpb.ConnectionServiceClient
	calls atomic.Int32
}

func (f *fakeConn) GetFollowersCount(context.Context, *connpb.UserRequest, ...grpc.CallOption) (*connpb.CountResponse, error) {
	f.calls.Add(1)
	return &connpb.CountResponse{Count: 7}, nil
}
func (f *fakeConn) GetFollowingCount(context.Context, *connpb.UserRequest, ...grpc.CallOption) (*connpb.CountResponse, error) {
	f.calls.Add(1)
	return &connpb.CountResponse{Count: 3}, nil
}
func (f *fakeConn) IsFollowing(context.Context, *connpb.IsFollowingRequest, ...grpc.CallOption) (*connpb.IsFollowingResponse, error) {
	f.calls.Add(1)
	return &connpb.IsFollowingResponse{IsFollowing: true}, nil
}

type fakePost struct {
	postpb.PostServiceClient
	byIDsCalls atomic.Int32
}

func (f *fakePost) GetPostsByIds(_ context.Context, in *postpb.GetPostsByIdsRequest, _ ...grpc.CallOption) (*postpb.GetPostsByIdsResponse, error) {
	f.byIDsCalls.Add(1)
	res := &postpb.GetPostsByIdsResponse{}
	for _, id := range in.Ids {
		if id != "missing" {
			res.Posts = append(res.Posts, &postpb.Post{Id: id, Content: "c", AuthorId: "author-" + id})
		}
	}
	return res, nil
}

type fakeCatalog struct {
	mu        sync.Mutex
	authCalls int
	cmtCalls  int
}

func (f *fakeCatalog) ListPosts(_ context.Context, limit int32) ([]*model.Post, error) {
	out := make([]*model.Post, 0, limit+5)
	for i := 0; i < int(limit)+5; i++ { // deliberately over-returns
		out = append(out, &model.Post{ID: fmt.Sprint(i)})
	}
	return out, nil
}
func (f *fakeCatalog) PostsByAuthors(_ context.Context, ids []string, _ int32) (map[string][]*model.Post, error) {
	f.mu.Lock()
	f.authCalls++
	f.mu.Unlock()
	out := map[string][]*model.Post{}
	for _, id := range ids {
		out[id] = []*model.Post{{ID: "p1-" + id}, {ID: "p2-" + id}, {ID: "p3-" + id}}
	}
	return out, nil
}
func (f *fakeCatalog) CommentsByPosts(_ context.Context, ids []string, _ int32) (map[string][]*model.Comment, error) {
	f.mu.Lock()
	f.cmtCalls++
	f.mu.Unlock()
	out := map[string][]*model.Comment{}
	for _, id := range ids {
		out[id] = []*model.Comment{{ID: "c-" + id, PostID: id, UserID: "u1"}}
	}
	return out, nil
}

type fakeRecommender struct{ ids []string }

func (f fakeRecommender) RecommendedUserIDs(context.Context, string, int32) ([]string, error) {
	return f.ids, nil
}

type fixture struct {
	r    *Resolver
	auth *fakeAuth
	prof *fakeProfile
	conn *fakeConn
	post *fakePost
}

func newFixture() *fixture {
	f := &fixture{auth: &fakeAuth{}, prof: &fakeProfile{}, conn: &fakeConn{}, post: &fakePost{}}
	f.r = &Resolver{AuthClient: f.auth, ProfileClient: f.prof, ConnectionClient: f.conn, PostClient: f.post}
	return f
}

// opCtx mimics what LoaderExtension + auth middleware give a real operation.
func (f *fixture) opCtx(viewer string) context.Context {
	ctx := context.Background()
	if viewer != "" {
		ctx = WithUserID(ctx, viewer)
	}
	return WithLoaders(ctx, NewLoaders(ctx, f.r, dataloader.Config{Wait: 20 * time.Millisecond}))
}

func parallel(n int, fn func(i int)) {
	var wg sync.WaitGroup
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) { defer wg.Done(); fn(i) }(i)
	}
	wg.Wait()
}

func TestPostAuthorsAreBatchedIntoOneUserLookup(t *testing.T) {
	f := newFixture()
	ctx := f.opCtx("viewer")
	pr := &postResolver{f.r}

	// 20 posts by 5 distinct authors.
	parallel(20, func(i int) {
		u, err := pr.Author(ctx, &model.Post{ID: fmt.Sprint(i), UserID: fmt.Sprintf("u%d", i%5)})
		if err != nil || u == nil {
			t.Errorf("author %d: %v, %v", i, u, err)
			return
		}
		if u.DisplayName == nil || *u.DisplayName != "Name "+u.ID {
			t.Errorf("profile not merged: %+v", u)
		}
		if u.FollowersCount != 7 || u.FollowingCount != 3 || !u.IsFollowing {
			t.Errorf("connection data not merged: %+v", u)
		}
	})

	if n := f.auth.calls.Load(); n != 1 {
		t.Errorf("expected 1 auth call, got %d", n)
	}
	if n := f.prof.calls.Load(); n != 1 {
		t.Errorf("expected 1 profile call, got %d", n)
	}
	if n := f.conn.calls.Load(); n != 15 { // 5 users x (followers + following + isFollowing)
		t.Errorf("expected 15 connection calls (5 users, deduped), got %d", n)
	}
}

func TestMissingAuthorIsAnError(t *testing.T) {
	f := newFixture()
	_, err := (&postResolver{f.r}).Author(f.opCtx("v"), &model.Post{UserID: "ghost"})
	if err == nil || !strings.Contains(err.Error(), "not found") {
		t.Fatalf("expected not-found error, got %v", err)
	}
}

func TestNotificationActorMissingIsNull(t *testing.T) {
	f := newFixture()
	u, err := (&notificationResolver{f.r}).Actor(f.opCtx("v"), &model.Notification{ActorID: "ghost"})
	if err != nil || u != nil {
		t.Fatalf("expected null actor, got %v, %v", u, err)
	}
}

func TestFeedItemPostsAreBatched(t *testing.T) {
	f := newFixture()
	ctx := f.opCtx("v")
	fr := &feedItemResolver{f.r}

	parallel(10, func(i int) {
		id := fmt.Sprint(i)
		if i == 9 {
			id = "missing"
		}
		p, err := fr.Post(ctx, &model.FeedItem{PostID: id})
		if err != nil {
			t.Errorf("post %s: %v", id, err)
		}
		if (id == "missing") != (p == nil) {
			t.Errorf("post %s: unexpected result %v", id, p)
		}
	})
	if n := f.post.byIDsCalls.Load(); n != 1 {
		t.Errorf("expected 1 GetPostsByIds call, got %d", n)
	}
}

func TestMapPostUsesAuthorID(t *testing.T) {
	p := mapPost(&postpb.Post{Id: "post-1", AuthorId: "alice"})
	if p.UserID != "alice" {
		t.Fatalf("Post.UserID must be the author, got %q", p.UserID)
	}
}

func TestNestedListsEmptyWithoutCatalog(t *testing.T) {
	f := newFixture()
	ctx := f.opCtx("v")
	posts, err := (&userResolver{f.r}).Posts(ctx, &model.User{ID: "u"}, nil)
	if err != nil || posts == nil || len(posts) != 0 {
		t.Fatalf("want empty non-nil list, got %v, %v", posts, err)
	}
	cm, err := (&postResolver{f.r}).Comments(ctx, &model.Post{ID: "p"}, nil)
	if err != nil || cm == nil || len(cm) != 0 {
		t.Fatalf("want empty non-nil list, got %v, %v", cm, err)
	}
	if _, err := (&queryResolver{f.r}).Posts(ctx, nil); err == nil || !strings.Contains(err.Error(), "unavailable") {
		t.Fatalf("Query.posts must report unavailable, got %v", err)
	}
}

func TestNestedListsUseCatalogInOneBatchAndHonourLimit(t *testing.T) {
	f := newFixture()
	cat := &fakeCatalog{}
	f.r.Catalog = cat
	ctx := f.opCtx("v")
	ur, pr := &userResolver{f.r}, &postResolver{f.r}
	two := int32(2)

	parallel(8, func(i int) {
		posts, err := ur.Posts(ctx, &model.User{ID: fmt.Sprintf("u%d", i)}, &two)
		if err != nil || len(posts) != 2 {
			t.Errorf("want 2 posts (limit enforced), got %d, %v", len(posts), err)
		}
		cms, err := pr.Comments(ctx, &model.Post{ID: fmt.Sprintf("p%d", i)}, nil)
		if err != nil || len(cms) != 1 {
			t.Errorf("want 1 comment, got %d, %v", len(cms), err)
		}
	})
	if cat.authCalls != 1 || cat.cmtCalls != 1 {
		t.Errorf("expected one batched call each, got posts=%d comments=%d", cat.authCalls, cat.cmtCalls)
	}

	for _, bad := range []int32{0, -1, 101} {
		bad := bad
		if _, err := ur.Posts(ctx, &model.User{ID: "u"}, &bad); err == nil {
			t.Errorf("limit %d should be rejected", bad)
		}
	}

	posts, err := (&queryResolver{f.r}).Posts(ctx, &two)
	if err != nil || len(posts) != 2 {
		t.Errorf("Query.posts must cap an over-returning catalog, got %d, %v", len(posts), err)
	}
}

func TestRecommendationsFilterSelfAndDuplicatesPreservingOrder(t *testing.T) {
	f := newFixture()
	f.r.Recommender = fakeRecommender{ids: []string{"b", "viewer", "a", "b", "ghost", "c"}}

	users, err := (&queryResolver{f.r}).Recommendations(f.opCtx("viewer"))
	if err != nil {
		t.Fatal(err)
	}
	var got []string
	for _, u := range users {
		got = append(got, u.ID)
	}
	if strings.Join(got, ",") != "b,a,c" {
		t.Fatalf("want b,a,c got %v", got)
	}

	f.r.Recommender = nil
	if _, err := (&queryResolver{f.r}).Recommendations(f.opCtx("viewer")); err == nil {
		t.Fatal("expected unavailable error")
	}
	if _, err := (&queryResolver{f.r}).Recommendations(f.opCtx("")); err == nil || err.Error() != "unauthorized" {
		t.Fatalf("expected unauthorized, got %v", err)
	}
}

func TestProfileQuery(t *testing.T) {
	f := newFixture()
	p, err := (&queryResolver{f.r}).Profile(context.Background(), "alice")
	if err != nil || p == nil || p.UserID != "alice" {
		t.Fatalf("got %+v, %v", p, err)
	}
}

// ---- subscription -----------------------------------------------------------

type fakeNotif struct {
	notificationpb.NotificationServiceClient
	mu    sync.Mutex
	calls int
	pages [][]*notificationpb.Notification // page returned on call i (last repeats)
}

func (f *fakeNotif) GetNotifications(context.Context, *notificationpb.GetNotificationsRequest, ...grpc.CallOption) (*notificationpb.GetNotificationsResponse, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	i := f.calls
	if i >= len(f.pages) {
		i = len(f.pages) - 1
	}
	f.calls++
	return &notificationpb.GetNotificationsResponse{Notifications: f.pages[i]}, nil
}

func n(id, at string) *notificationpb.Notification {
	return &notificationpb.Notification{Id: id, UserId: "alice", Type: "like", ActorId: "bob", CreatedAt: at}
}

func TestSubscriptionEmitsOnlyNewNotificationsOldestFirstAndClosesOnCancel(t *testing.T) {
	fn := &fakeNotif{pages: [][]*notificationpb.Notification{
		{n("1", "2026-01-01T00:00:01Z")}, // priming poll: must NOT be replayed
		{n("3", "2026-01-01T00:00:03Z"), n("2", "2026-01-01T00:00:02Z"), n("1", "2026-01-01T00:00:01Z")},
		{n("3", "2026-01-01T00:00:03Z"), n("2", "2026-01-01T00:00:02Z"), n("1", "2026-01-01T00:00:01Z")},
	}}
	r := &Resolver{NotificationClient: fn, NotificationPollInterval: 10 * time.Millisecond}
	sr := &subscriptionResolver{r}

	if _, err := sr.NotificationReceived(context.Background(), "alice"); err == nil || err.Error() != "unauthorized" {
		t.Fatalf("want unauthorized, got %v", err)
	}
	if _, err := sr.NotificationReceived(WithUserID(context.Background(), "mallory"), "alice"); err == nil || !strings.Contains(err.Error(), "forbidden") {
		t.Fatalf("want forbidden, got %v", err)
	}

	ctx, cancel := context.WithCancel(WithUserID(context.Background(), "alice"))
	defer cancel()
	ch, err := sr.NotificationReceived(ctx, "alice")
	if err != nil {
		t.Fatal(err)
	}

	var got []string
	for len(got) < 2 {
		select {
		case ev := <-ch:
			got = append(got, ev.ID)
		case <-time.After(2 * time.Second):
			t.Fatalf("timed out, got %v", got)
		}
	}
	if strings.Join(got, ",") != "2,3" {
		t.Fatalf("want 2,3 (oldest first, no replay of 1), got %v", got)
	}

	// No duplicates on later polls, and cancel closes the channel.
	select {
	case ev := <-ch:
		t.Fatalf("unexpected duplicate %s", ev.ID)
	case <-time.After(60 * time.Millisecond):
	}
	cancel()
	select {
	case _, ok := <-ch:
		if ok {
			t.Fatal("channel should be closed after cancel")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("channel not closed after cancel")
	}
}

func TestSubscriptionEndsWhenTokenExpires(t *testing.T) {
	fn := &fakeNotif{pages: [][]*notificationpb.Notification{{}}}
	r := &Resolver{NotificationClient: fn, NotificationPollInterval: 10 * time.Millisecond}
	ctx := WithAuthExpiry(WithUserID(context.Background(), "alice"), time.Now().Add(40*time.Millisecond))
	ch, err := (&subscriptionResolver{r}).NotificationReceived(ctx, "alice")
	if err != nil {
		t.Fatal(err)
	}
	select {
	case _, ok := <-ch:
		if ok {
			t.Fatal("unexpected event")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("subscription outlived its token")
	}
}

// ---- complexity -------------------------------------------------------------

func TestComplexityMultipliesByLimit(t *testing.T) {
	c := DefaultComplexity()
	hundred := int32(100)
	if got := c.User.Posts(5, &hundred); got != 501 {
		t.Errorf("User.posts(100) child 5 = %d, want 501", got)
	}
	if got := c.Post.Comments(5, nil); got != 51 { // default limit 10
		t.Errorf("Post.comments default = %d, want 51", got)
	}
	// A recursive query must cost far more than any sane limit.
	level := 1
	for i := 0; i < 4; i++ {
		level = c.User.Posts(level+1, &hundred)
	}
	if level < 5000 {
		t.Errorf("recursive fan-out should exceed the default limit, got %d", level)
	}
	if got := c.Query.Users(2, nil); got != 3 {
		t.Errorf("empty id list must stay non-negative/cheap, got %d", got)
	}
}

var _ = feedpb.GetFeedRequest{} // keep the import if tests are trimmed
