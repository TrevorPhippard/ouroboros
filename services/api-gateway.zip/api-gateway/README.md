# API Gateway

GraphQL gateway for the Ouroboros auth, connection, feed, notification, post, and profile gRPC services.

## Prerequisites

- Go version `1.25.8` (as declared in `go.mod`).
- The parent Ouroboros repository/workspace containing `ouroboros/proto/generated/{auth,connection,feed,notification,post,profile}`. Those generated protobuf packages are not included in this gateway-only archive.
- The auth service must issue HS256 JWTs for the included HTTP auth middleware, with an `exp` claim and a user identifier in one of `sub`, `user_id`, `userId`, `userID`, or `id`.

## Configuration

The following environment variables are supported:

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `4000` | HTTP listen port |
| `AUTH_SERVICE_URL` | `localhost:50053` | Auth gRPC endpoint |
| `CONNECTION_SERVICE_URL` | `localhost:50054` | Connection gRPC endpoint |
| `FEED_SERVICE_URL` | `localhost:50055` | Feed gRPC endpoint |
| `NOTIFICATION_SERVICE_URL` | `localhost:50056` | Notification gRPC endpoint |
| `POST_SERVICE_URL` | `localhost:50057` | Post gRPC endpoint |
| `PROFILE_SERVICE_URL` | `localhost:50058` | Profile gRPC endpoint |
| `JWT_SECRET` | unset | Shared HS256 verification secret; protected operations fail closed if unset. There is no default |
| `CORS_ALLOWED_ORIGINS` | `http://localhost:3000,http://127.0.0.1:3000` | Comma-separated browser origins |
| `ENABLE_PLAYGROUND` | `false` | Set to `true` to expose GraphQL Playground at `/` (off by default, it is not served otherwise) |
| `GRAPHQL_COMPLEXITY_LIMIT` | `5000` | Maximum query cost; list fields cost `limit x children`, so recursive fan-out is rejected |
| `NOTIFICATION_POLL_INTERVAL` | `3s` | How often a `notificationReceived` subscription polls the Notification service |

The gateway forwards a supplied bearer token to gRPC services as `authorization` metadata. It only trusts the user ID after verifying the JWT itself with `JWT_SECRET`.

## Build, generation, and tests

Run these commands from this directory in the complete Ouroboros workspace:

```sh
make generate
go test ./...
go run ./cmd
```

`make generate` refreshes `graph/generated.go` and `graph/model/models_gen.go` from `graph/schema.graphqls`. The generated files were inconsistent with the checked-in schema in the supplied archive, so code generation should be run whenever the schema changes.

## Data loaders

Every GraphQL operation gets its own set of batching loaders (`graph/loaders.go`,
installed by `graph.LoaderExtension`; generic implementation in
`graph/dataloader`). Nested fields (`Post.author`, `Comment.author`,
`Notification.actor`, `FeedItem.post`, `User.posts`, `Post.comments`) are lazy
field resolvers, so all keys requested at one level of a query are fetched with
one downstream call, de-duplicated and cached for the rest of that operation:

The previous code already batched the auth/profile lookups inside individual
resolvers, but could not share work *across* fields (e.g. post authors and
comment authors, or `User.posts` for many users). Now e.g. `postsByIds(20) { author
comments { author } }` costs one user lookup per nesting level, however many
posts/comments there are.

Per-user follow counts have no batch RPC, so they run concurrently (max 16 at a
time) instead of one after another. Subscriptions use non-caching loaders so a
long-lived stream never serves stale users. Mutations evict the affected user.

## Subscriptions

`notificationReceived(userId)` works over WebSocket (`graphql-ws`/`graphql-transport-ws`).
Browsers cannot set headers on a WebSocket, so send the token in
`connection_init`: `{"Authorization": "Bearer <jwt>"}`. The Notification service has
no streaming RPC, so the gateway polls it and emits each new notification once,
oldest first. Existing notifications are not replayed (use `notifications`). The
stream ends on disconnect or when the token's `exp` passes. The WebSocket origin
check uses `CORS_ALLOWED_ORIGINS`.

## Build, generation, and tests

Run these commands from this directory in the complete Ouroboros workspace:

```sh
go run github.com/99designs/gqlgen generate   # or `make generate`
go test -race ./...
go run ./cmd
```

The schema is split per domain (`graph/*.graphqls`) so gqlgen's follow-schema
layout keeps one `<domain>.resolvers.go` per file. **Keep helpers out of
`*.resolvers.go`**: gqlgen comments out anything in those files that is not a
resolver method. Put them in plain files such as `graph/mapping.go`.

## Fields that need new backend RPCs

`Query.posts`, `User.posts`, `Post.comments` and `Query.recommendations` are fully
implemented in the gateway, but the Post and Connection services do not expose the
list RPCs they need. By default `Query.posts` / `Query.recommendations` return an
explicit "unavailable" error and the nested lists are empty. See
[docs/proto-extensions.md](docs/proto-extensions.md) for the proposed RPCs and how
to enable them with `-tags postext`.

## Verification status

`go vet`, `gofmt` and `go test -race ./...` pass (including end-to-end tests through the
generated schema) in a scratch module where `ouroboros/proto/generated/*` was replaced by
minimal stand-ins mirroring only the fields this gateway uses. The real generated
packages were not available, so run the build and tests once in the full workspace.
