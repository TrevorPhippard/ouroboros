//go:build !postext

package main

import (
	"api-gateway/graph"

	"google.golang.org/grpc"
)

// newExtensions returns no optional capabilities: the Post and Connection
// services do not yet expose the RPCs they would need. Query.posts and
// Query.recommendations then report an explicit "unavailable" error, and the
// nested User.posts / Post.comments lists are empty.
func newExtensions(_, _ *grpc.ClientConn) (graph.PostCatalog, graph.Recommender) {
	return nil, nil
}
