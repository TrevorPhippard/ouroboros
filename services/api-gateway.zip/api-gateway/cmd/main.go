package main

import (
	"log"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"api-gateway/graph"

	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/99designs/gqlgen/graphql/handler/extension"
	"github.com/99designs/gqlgen/graphql/handler/lru"
	"github.com/99designs/gqlgen/graphql/handler/transport"
	"github.com/99designs/gqlgen/graphql/playground"
	"github.com/gorilla/websocket"
	"github.com/rs/cors"
	"github.com/vektah/gqlparser/v2/ast"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	// Importing specific generated proto packages
	authpb "ouroboros/proto/generated/auth"
	connpb "ouroboros/proto/generated/connection"
	feedpb "ouroboros/proto/generated/feed"
	notifpb "ouroboros/proto/generated/notification"
	postpb "ouroboros/proto/generated/post"
	profilepb "ouroboros/proto/generated/profile"
)

// Helper function to get env or fallback
func getEnv(key, fallback string) string {
	if value, exists := os.LookupEnv(key); exists && strings.TrimSpace(value) != "" {
		return strings.TrimSpace(value)
	}
	return fallback
}

// string to list
func csvEnv(key string, fallback []string) []string {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback
	}

	var values []string
	for _, item := range strings.Split(value, ",") {
		item = strings.TrimSpace(item)
		if item != "" {
			values = append(values, item)
		}
	}
	if len(values) == 0 {
		return fallback
	}
	return values
}

// boolEnv parses a boolean environment variable, falling back on anything
// unset or unparsable.
func boolEnv(key string, fallback bool) bool {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback
	}
	parsed, err := strconv.ParseBool(value)
	if err != nil {
		log.Printf("WARNING: ignoring invalid %s=%q (want true/false)", key, value)
		return fallback
	}
	return parsed
}

// intEnv parses a positive integer environment variable.
func intEnv(key string, fallback int) int {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback
	}
	parsed, err := strconv.Atoi(value)
	if err != nil || parsed < 1 {
		log.Printf("WARNING: ignoring invalid %s=%q (want a positive integer)", key, value)
		return fallback
	}
	return parsed
}

// durationEnv parses a positive duration such as "5s" or "250ms".
func durationEnv(key string, fallback time.Duration) time.Duration {
	value := strings.TrimSpace(os.Getenv(key))
	if value == "" {
		return fallback
	}
	parsed, err := time.ParseDuration(value)
	if err != nil || parsed <= 0 {
		log.Printf("WARNING: ignoring invalid %s=%q (want a positive duration like 3s)", key, value)
		return fallback
	}
	return parsed
}

// originAllowed reports whether a browser Origin may open a WebSocket. It
// mirrors the CORS allow-list so the two can never disagree. Requests without
// an Origin header (non-browser clients) are allowed, as they are by CORS.
func originAllowed(origin string, allowed []string) bool {
	if origin == "" {
		return true
	}
	for _, candidate := range allowed {
		if candidate == "*" || strings.EqualFold(candidate, origin) {
			return true
		}
	}
	return false
}

// newGraphQLServer builds the GraphQL handler. It mirrors gqlgen's
// NewDefaultServer (query cache, introspection, persisted queries) but adds
// what a public gateway needs: per-request data loaders, a query complexity
// limit, authenticated WebSocket subscriptions with an origin check, and no
// multipart upload transport (the schema has no uploads).
func newGraphQLServer(resolver *graph.Resolver, jwtSecret string, allowedOrigins []string) *handler.Server {
	srv := handler.New(graph.NewExecutableSchema(graph.Config{
		Resolvers:  resolver,
		Complexity: graph.DefaultComplexity(),
	}))

	srv.AddTransport(transport.Websocket{
		KeepAlivePingInterval: 10 * time.Second,
		InitFunc:              websocketInit(jwtSecret),
		Upgrader: websocket.Upgrader{
			CheckOrigin: func(r *http.Request) bool {
				return originAllowed(r.Header.Get("Origin"), allowedOrigins)
			},
		},
	})
	srv.AddTransport(transport.Options{})
	srv.AddTransport(transport.GET{})
	srv.AddTransport(transport.POST{})

	srv.SetQueryCache(lru.New[*ast.QueryDocument](1000))
	srv.Use(extension.Introspection{})
	srv.Use(extension.AutomaticPersistedQuery{Cache: lru.New[string](100)})
	srv.Use(extension.FixedComplexityLimit(intEnv("GRAPHQL_COMPLEXITY_LIMIT", 5000)))
	srv.Use(graph.LoaderExtension(resolver))
	return srv
}

// dialService encapsulates gRPC client creation and fatal error handling.
func dialService(name, envKey, defaultURL string, opts []grpc.DialOption) *grpc.ClientConn {
	url := getEnv(envKey, defaultURL)
	conn, err := grpc.NewClient(url, opts...)
	if err != nil {
		log.Fatalf("could not connect to %s service at %s: %v", name, url, err)
	}
	return conn
}

func main() {
	port := getEnv("PORT", "4000")

	dialOptions := []grpc.DialOption{
		//does not use TLS encryption
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	}

	// Initialize gRPC service connections cleanly
	authConn := dialService("auth", "AUTH_SERVICE_URL", "localhost:50053", dialOptions)
	defer authConn.Close()

	connConn := dialService("connection", "CONNECTION_SERVICE_URL", "localhost:50054", dialOptions)
	defer connConn.Close()

	feedConn := dialService("feed", "FEED_SERVICE_URL", "localhost:50055", dialOptions)
	defer feedConn.Close()

	notifConn := dialService("notification", "NOTIFICATION_SERVICE_URL", "localhost:50056", dialOptions)
	defer notifConn.Close()

	postConn := dialService("post", "POST_SERVICE_URL", "localhost:50057", dialOptions)
	defer postConn.Close()

	profileConn := dialService("profile", "PROFILE_SERVICE_URL", "localhost:50058", dialOptions)
	defer profileConn.Close()

	// Optional capabilities that need Post/Connection RPCs beyond today's API.
	// Both are nil unless the binary is built with -tags postext.
	catalog, recommender := newExtensions(postConn, connConn)
	if catalog == nil {
		log.Printf("post catalog not configured: Query.posts is unavailable and User.posts / Post.comments return empty lists (build with -tags postext once the Post service exposes the list RPCs)")
	}
	if recommender == nil {
		log.Printf("recommender not configured: Query.recommendations is unavailable (build with -tags postext once the Connection service exposes GetRecommendations)")
	}

	// Initialize Resolver with specific clients
	resolver := &graph.Resolver{
		AuthClient:               authpb.NewAuthServiceClient(authConn),
		ConnectionClient:         connpb.NewConnectionServiceClient(connConn),
		FeedClient:               feedpb.NewFeedServiceClient(feedConn),
		NotificationClient:       notifpb.NewNotificationServiceClient(notifConn),
		PostClient:               postpb.NewPostServiceClient(postConn),
		ProfileClient:            profilepb.NewProfileServiceClient(profileConn),
		Catalog:                  catalog,
		Recommender:              recommender,
		NotificationPollInterval: durationEnv("NOTIFICATION_POLL_INTERVAL", 3*time.Second),
	}

	// Never fall back to a default secret: a guessable one lets anyone mint
	// valid tokens. Without a secret, protected operations fail closed.
	jwtSecret := strings.TrimSpace(os.Getenv("JWT_SECRET"))
	if jwtSecret == "" {
		log.Printf("WARNING: JWT_SECRET is not set; authenticated GraphQL operations will be rejected")
	}

	allowedOrigins := csvEnv("CORS_ALLOWED_ORIGINS", []string{"http://localhost:3000", "http://127.0.0.1:3000"})
	srv := newGraphQLServer(resolver, jwtSecret, allowedOrigins)

	// Configure CORS through the environment instead of hard-coding one LAN IP.
	c := cors.New(cors.Options{
		AllowedOrigins:   allowedOrigins,
		AllowCredentials: true,
		AllowedMethods:   []string{"GET", "POST", "OPTIONS"},
		AllowedHeaders:   []string{"Authorization", "Content-Type"},
	})

	mux := http.NewServeMux()

	//This wraps your GraphQL handler with a request body size limit.
	// 1,048,576 bytes = 1 MiB
	graphqlHandler := http.MaxBytesHandler(srv, 1<<20)
	// Register both GraphQL endpoints.

	mux.Handle("/graphql", graphqlHandler)
	mux.Handle("/query", graphqlHandler) // Backward compatibility

	// The playground is a development tool: expose it only when asked to.
	if boolEnv("ENABLE_PLAYGROUND", false) {
		mux.Handle("/", playground.Handler("GraphQL Playground", "/graphql"))
	}

	// Health check.
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}

		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok\n"))
	})

	server := &http.Server{
		Addr:              ":" + port,
		Handler:           c.Handler(AuthContextMiddleware(jwtSecret, mux)),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       15 * time.Second,
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	log.Printf("Ouroboros Gateway listening on :%s", port)
	log.Fatal(server.ListenAndServe())
}
