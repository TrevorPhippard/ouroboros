//go:build postext

package main

import (
	"api-gateway/graph"

	"google.golang.org/grpc"

	connpb "ouroboros/proto/generated/connection"
	postpb "ouroboros/proto/generated/post"
)

// newExtensions wires the optional Post-list and recommendation capabilities.
// Built only with -tags postext (see docs/proto-extensions.md).
func newExtensions(postConn, connConn *grpc.ClientConn) (graph.PostCatalog, graph.Recommender) {
	return graph.NewGRPCCatalog(postpb.NewPostServiceClient(postConn)),
		graph.NewGRPCRecommender(connpb.NewConnectionServiceClient(connConn))
}
