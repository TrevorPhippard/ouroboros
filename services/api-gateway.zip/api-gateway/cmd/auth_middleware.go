package main

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"

	"api-gateway/graph"

	"github.com/99designs/gqlgen/graphql/handler/transport"
	"google.golang.org/grpc/metadata"
)

// AuthContextMiddleware verifies HS256 bearer tokens when JWT_SECRET is set,
// adds the verified user ID to the GraphQL context, and forwards the bearer
// token to downstream gRPC services as authorization metadata. It intentionally
// does not reject every unauthenticated request because sign-up/sign-in are
// public operations; protected resolvers fail closed when no user ID is set.
func AuthContextMiddleware(secret string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx := authenticate(r.Context(), bearerToken(r.Header.Get("Authorization")), secret, time.Now())
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// authenticate attaches a bearer token's identity to ctx. The token is always
// forwarded to downstream services (they validate it too); the gateway only
// trusts the user ID and expiry after verifying the signature itself.
func authenticate(ctx context.Context, token, secret string, now time.Time) context.Context {
	if token == "" {
		return ctx
	}
	ctx = metadata.AppendToOutgoingContext(ctx, "authorization", "Bearer "+token)
	if secret == "" {
		return ctx
	}
	if userID, expiresAt, ok := verifyHS256JWT(token, secret, now); ok {
		ctx = graph.WithUserID(ctx, userID)
		ctx = graph.WithAuthExpiry(ctx, expiresAt)
	}
	return ctx
}

// websocketInit authenticates a WebSocket connection. Browsers cannot set an
// Authorization header on a WebSocket, so graphql-ws clients send the bearer
// token in the connection_init payload instead (as "Authorization" or
// "authorization"). A token in the upgrade request's header, already handled by
// AuthContextMiddleware, keeps working when the payload has none.
func websocketInit(secret string) transport.WebsocketInitFunc {
	return func(ctx context.Context, payload transport.InitPayload) (context.Context, *transport.InitPayload, error) {
		header := payload.Authorization()
		if header == "" {
			if v, ok := payload["authorization"].(string); ok {
				header = v
			}
		}
		if token := bearerToken(header); token != "" {
			ctx = authenticate(ctx, token, secret, time.Now())
		}
		return ctx, &payload, nil
	}
}

func bearerToken(header string) string {
	parts := strings.Fields(header)
	if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
		return ""
	}
	return parts[1]
}

// verifyHS256JWT validates an HS256 token's signature and time claims and
// returns the user ID and expiry it carries.
func verifyHS256JWT(token, secret string, now time.Time) (userID string, expiresAt time.Time, ok bool) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 || secret == "" {
		return "", time.Time{}, false
	}

	headerBytes, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil {
		return "", time.Time{}, false
	}
	var header struct {
		Algorithm string `json:"alg"`
	}
	if err := json.Unmarshal(headerBytes, &header); err != nil || header.Algorithm != "HS256" {
		return "", time.Time{}, false
	}

	providedSignature, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil {
		return "", time.Time{}, false
	}
	mac := hmac.New(sha256.New, []byte(secret))
	_, _ = mac.Write([]byte(parts[0] + "." + parts[1]))
	if !hmac.Equal(providedSignature, mac.Sum(nil)) {
		return "", time.Time{}, false
	}

	claimsBytes, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return "", time.Time{}, false
	}
	var claims map[string]any
	if err := json.Unmarshal(claimsBytes, &claims); err != nil {
		return "", time.Time{}, false
	}

	exp, exists := claims["exp"]
	if !exists {
		return "", time.Time{}, false
	}
	expiration, ok := numericClaim(exp)
	if !ok || now.Unix() >= expiration {
		return "", time.Time{}, false
	}
	if nbf, exists := claims["nbf"]; exists {
		timestamp, ok := numericClaim(nbf)
		if !ok || now.Unix() < timestamp {
			return "", time.Time{}, false
		}
	}

	for _, key := range []string{"sub", "user_id", "userId", "userID", "id"} {
		if value, ok := claims[key].(string); ok && strings.TrimSpace(value) != "" {
			userID = strings.TrimSpace(value)
			break
		}
	}
	if userID == "" {
		return "", time.Time{}, false
	}
	return userID, time.Unix(expiration, 0), true
}

func numericClaim(value any) (int64, bool) {
	switch v := value.(type) {
	case float64:
		return int64(v), v == float64(int64(v))
	case json.Number:
		n, err := strconv.ParseInt(v.String(), 10, 64)
		return n, err == nil
	default:
		return 0, false
	}
}
