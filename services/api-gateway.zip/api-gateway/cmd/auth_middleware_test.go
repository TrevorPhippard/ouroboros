package main

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"api-gateway/graph"

	"github.com/99designs/gqlgen/graphql/handler/transport"
	"google.golang.org/grpc/metadata"
)

const testSecret = "test-secret"

func b64(v any) string {
	raw, _ := json.Marshal(v)
	return base64.RawURLEncoding.EncodeToString(raw)
}

func mint(secret string, header, claims map[string]any) string {
	signing := b64(header) + "." + b64(claims)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(signing))
	return signing + "." + base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
}

func hs256(claims map[string]any) string {
	return mint(testSecret, map[string]any{"alg": "HS256", "typ": "JWT"}, claims)
}

func TestVerifyHS256JWT(t *testing.T) {
	now := time.Unix(1_800_000_000, 0)
	exp := now.Add(time.Hour).Unix()

	good := hs256(map[string]any{"sub": "alice", "exp": exp})
	uid, expiresAt, ok := verifyHS256JWT(good, testSecret, now)
	if !ok || uid != "alice" || expiresAt.Unix() != exp {
		t.Fatalf("valid token rejected: %q %v %v", uid, expiresAt, ok)
	}

	cases := map[string]string{
		"expired":      hs256(map[string]any{"sub": "a", "exp": now.Add(-time.Second).Unix()}),
		"no exp":       hs256(map[string]any{"sub": "a"}),
		"not yet":      hs256(map[string]any{"sub": "a", "exp": exp, "nbf": now.Add(time.Minute).Unix()}),
		"no user":      hs256(map[string]any{"exp": exp}),
		"wrong secret": mint("other", map[string]any{"alg": "HS256"}, map[string]any{"sub": "a", "exp": exp}),
		"alg none":     mint(testSecret, map[string]any{"alg": "none"}, map[string]any{"sub": "a", "exp": exp}),
		"garbage":      "not.a.jwt",
	}
	for name, tok := range cases {
		if _, _, ok := verifyHS256JWT(tok, testSecret, now); ok {
			t.Errorf("%s token must be rejected", name)
		}
	}
	if _, _, ok := verifyHS256JWT(good, "", now); ok {
		t.Error("an empty secret must never verify anything")
	}
}

func TestWebsocketInitAuthenticatesFromPayload(t *testing.T) {
	tok := hs256(map[string]any{"sub": "alice", "exp": time.Now().Add(time.Hour).Unix()})
	init := websocketInit(testSecret)

	for _, key := range []string{"Authorization", "authorization"} {
		ctx, _, err := init(context.Background(), transport.InitPayload{key: "Bearer " + tok})
		if err != nil {
			t.Fatal(err)
		}
		// The verified identity is what resolvers read; prove it via a resolver gate.
		sr := &graph.Resolver{}
		if _, err := sr.Subscription().NotificationReceived(ctx, "bob"); err == nil || err.Error() == "unauthorized" {
			t.Errorf("%s: payload token should authenticate (expected forbidden for other user), got %v", key, err)
		}
		md, _ := metadata.FromOutgoingContext(ctx)
		if got := md.Get("authorization"); len(got) != 1 || got[0] != "Bearer "+tok {
			t.Errorf("%s: token must be forwarded downstream, got %v", key, got)
		}
	}

	// Forged token: forwarded for the backend to judge, but never trusted here.
	forged := mint("attacker", map[string]any{"alg": "HS256"}, map[string]any{"sub": "alice", "exp": time.Now().Add(time.Hour).Unix()})
	ctx, _, _ := init(context.Background(), transport.InitPayload{"Authorization": "Bearer " + forged})
	if _, err := (&graph.Resolver{}).Subscription().NotificationReceived(ctx, "alice"); err == nil || err.Error() != "unauthorized" {
		t.Errorf("forged token must stay unauthenticated, got %v", err)
	}
}

func TestOriginAllowed(t *testing.T) {
	allowed := []string{"http://localhost:3000"}
	cases := []struct {
		origin string
		want   bool
	}{
		{"", true}, {"http://localhost:3000", true}, {"HTTP://LOCALHOST:3000", true},
		{"http://evil.example", false}, {"http://localhost:3001", false},
	}
	for _, c := range cases {
		if got := originAllowed(c.origin, allowed); got != c.want {
			t.Errorf("origin %q = %v, want %v", c.origin, got, c.want)
		}
	}
	if !originAllowed("http://anything", []string{"*"}) {
		t.Error("wildcard should allow any origin")
	}
}

var _ = fmt.Sprint
